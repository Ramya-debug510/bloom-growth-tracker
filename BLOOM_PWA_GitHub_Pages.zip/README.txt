BLOOM PWA GitHub Pages setup
1. Create a GitHub repository.
2. Upload index.html, manifest.webmanifest, service-worker.js and icon.svg to the repository root.
3. Open Settings -> Pages.
4. Select Deploy from a branch, branch main, folder /(root), then Save.
5. Wait for the HTTPS website URL shown by GitHub Pages.
6. Open that URL in Android Chrome. Tap the three-dot menu and choose Install app or Add to Home screen.

Progress is stored separately in each browser/device; this package does not sync phone and laptop data. Avoid adding private information to a public repository.
